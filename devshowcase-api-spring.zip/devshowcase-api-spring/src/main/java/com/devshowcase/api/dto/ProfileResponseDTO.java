package com.devshowcase.api.dto;

import com.devshowcase.api.model.Profile;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

public class ProfileResponseDTO {

    private Long id;
    private String name;
    private String bio;
    private String email;
    private String githubUrl;
    private List<ProjectSummaryDTO> projects;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static ProfileResponseDTO from(Profile profile) {
        ProfileResponseDTO dto = new ProfileResponseDTO();
        dto.id = profile.getId();
        dto.name = profile.getName();
        dto.bio = profile.getBio();
        dto.email = profile.getEmail();
        dto.githubUrl = profile.getGithubUrl();
        dto.createdAt = profile.getCreatedAt();
        dto.updatedAt = profile.getUpdatedAt();
        if (profile.getProjects() != null) {
            dto.projects = profile.getProjects().stream()
                .map(p -> new ProjectSummaryDTO(p.getId(), p.getTitle()))
                .collect(Collectors.toList());
        }
        return dto;
    }

    public static class ProjectSummaryDTO {
        private Long id;
        private String title;

        public ProjectSummaryDTO(Long id, String title) {
            this.id = id;
            this.title = title;
        }

        public Long getId() { return id; }
        public String getTitle() { return title; }
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getBio() { return bio; }
    public String getEmail() { return email; }
    public String getGithubUrl() { return githubUrl; }
    public List<ProjectSummaryDTO> getProjects() { return projects; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
