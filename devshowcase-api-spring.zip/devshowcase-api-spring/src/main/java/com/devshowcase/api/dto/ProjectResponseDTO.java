package com.devshowcase.api.dto;

import com.devshowcase.api.model.Project;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.stream.Collectors;

public class ProjectResponseDTO {

    private Long id;
    private String title;
    private String description;
    private String repositoryUrl;
    private String demoUrl;
    private Long profileId;
    private Set<TechnologyResponseDTO> technologies;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static ProjectResponseDTO from(Project project) {
        ProjectResponseDTO dto = new ProjectResponseDTO();
        dto.id = project.getId();
        dto.title = project.getTitle();
        dto.description = project.getDescription();
        dto.repositoryUrl = project.getRepositoryUrl();
        dto.demoUrl = project.getDemoUrl();
        dto.profileId = project.getProfile() != null ? project.getProfile().getId() : null;
        dto.technologies = project.getTechnologies().stream()
            .map(TechnologyResponseDTO::from)
            .collect(Collectors.toSet());
        dto.createdAt = project.getCreatedAt();
        dto.updatedAt = project.getUpdatedAt();
        return dto;
    }

    public Long getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getRepositoryUrl() { return repositoryUrl; }
    public String getDemoUrl() { return demoUrl; }
    public Long getProfileId() { return profileId; }
    public Set<TechnologyResponseDTO> getTechnologies() { return technologies; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
