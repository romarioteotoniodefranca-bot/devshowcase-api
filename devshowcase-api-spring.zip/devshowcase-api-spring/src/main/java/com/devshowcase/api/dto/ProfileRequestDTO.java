package com.devshowcase.api.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public class ProfileRequestDTO {

    @NotBlank(message = "O campo 'name' é obrigatório e não pode ser vazio.")
    private String name;

    private String bio;

    @NotBlank(message = "O campo 'email' é obrigatório.")
    @Email(message = "O campo 'email' deve ser um e-mail válido.")
    private String email;

    @Pattern(regexp = "^$|^(https?://).+", message = "O campo 'githubUrl', quando informado, deve ser uma URL válida.")
    private String githubUrl;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getGithubUrl() { return githubUrl; }
    public void setGithubUrl(String githubUrl) { this.githubUrl = githubUrl; }
}
