package com.devshowcase.api.controller;

import com.devshowcase.api.dto.TechnologyRequestDTO;
import com.devshowcase.api.dto.TechnologyResponseDTO;
import com.devshowcase.api.model.Technology;
import com.devshowcase.api.repository.TechnologyRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/technologies")
public class TechnologyController {

    private final TechnologyRepository technologyRepository;

    public TechnologyController(TechnologyRepository technologyRepository) {
        this.technologyRepository = technologyRepository;
    }

    @PostMapping
    public ResponseEntity<TechnologyResponseDTO> create(@Valid @RequestBody TechnologyRequestDTO request) {
        Technology technology = new Technology();
        technology.setName(request.getName());

        Technology saved = technologyRepository.save(technology);
        return ResponseEntity.status(HttpStatus.CREATED).body(TechnologyResponseDTO.from(saved));
    }

    @GetMapping
    public ResponseEntity<List<TechnologyResponseDTO>> listAll() {
        List<TechnologyResponseDTO> technologies = technologyRepository.findAll().stream()
            .map(TechnologyResponseDTO::from)
            .collect(Collectors.toList());
        return ResponseEntity.ok(technologies);
    }
}
