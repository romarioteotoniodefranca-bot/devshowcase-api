package com.devshowcase.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.util.List;

public class ProjectRequestDTO {

    @NotBlank(message = "O campo 'title' é obrigatório e não pode ser vazio.")
    private String title;

    private String description;

    @NotBlank(message = "O campo 'repositoryUrl' é obrigatório.")
    @Pattern(regexp = "^(https?://).+", message = "O campo 'repositoryUrl' deve ser uma URL válida.")
    private String repositoryUrl;

    @Pattern(regexp = "^$|^(https?://).+", message = "O campo 'demoUrl', quando informado, deve ser uma URL válida.")
    private String demoUrl;

    @NotNull(message = "O campo 'profileId' é obrigatório.")
    private Long profileId;

    private List<Long> technologyIds;

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getRepositoryUrl() { return repositoryUrl; }
    public void setRepositoryUrl(String repositoryUrl) { this.repositoryUrl = repositoryUrl; }

    public String getDemoUrl() { return demoUrl; }
    public void setDemoUrl(String demoUrl) { this.demoUrl = demoUrl; }

    public Long getProfileId() { return profileId; }
    public void setProfileId(Long profileId) { this.profileId = profileId; }

    public List<Long> getTechnologyIds() { return technologyIds; }
    public void setTechnologyIds(List<Long> technologyIds) { this.technologyIds = technologyIds; }
}
