package com.devshowcase.api.dto;

import jakarta.validation.constraints.NotBlank;

public class TechnologyRequestDTO {

    @NotBlank(message = "O campo 'name' é obrigatório e não pode ser vazio.")
    private String name;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
