package com.devshowcase.api.dto;

import com.devshowcase.api.model.Technology;

import java.time.LocalDateTime;

public class TechnologyResponseDTO {

    private Long id;
    private String name;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static TechnologyResponseDTO from(Technology technology) {
        TechnologyResponseDTO dto = new TechnologyResponseDTO();
        dto.id = technology.getId();
        dto.name = technology.getName();
        dto.createdAt = technology.getCreatedAt();
        dto.updatedAt = technology.getUpdatedAt();
        return dto;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
